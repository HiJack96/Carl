import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
//import java.awt.*;

public class Main {
	private static ArrayList<Converse> catalogue = new ArrayList<Converse>();

	private static void loadFile() {
		ArrayList dummyList = new ArrayList();
		File data = new File("ConversationCatalogue.sav");
		try {
			if(!data.exists()) {
				if(data.createNewFile()) 
					System.out.print("Hello! My name is Carl. I am an AI created by Jack Bachman. \nIf you are reading this, then that means that I must have \nforgotten how to talk with people. Which means, \nyou are going to have to teach me the basics. So...");
				catalogue.add(new Converse("Hello!", "Hello!", 1) );
			} else {
				try {
					FileInputStream savedFile = new FileInputStream("ConversationCatalogue.sav");
					ObjectInputStream restore = new ObjectInputStream(savedFile);
					dummyList = (ArrayList) restore.readObject();
					restore.close();
				} catch(Exception exc) { exc.printStackTrace(); }
	
				Converse dummy = new Converse();
				for(java.lang.Object arg : dummyList) {
					dummy = (Converse) arg;
					catalogue.add(dummy);
				}
			}
			data.delete();
		} catch(Exception exc) { exc.printStackTrace(); }
	}

	private static void saveFile() {
		try {
			FileOutputStream savedFile = new FileOutputStream("ConversationCatalogue.sav");
			ObjectOutputStream save = new ObjectOutputStream(savedFile);
			save.writeObject(catalogue);
			save.close();
		} catch(Exception exc) { exc.printStackTrace();}
	}
	
	public static void main(String[] args) {
		loadFile();
		Scanner scan = new Scanner(System.in);
		System.out.println("Hello!");
		String input = scan.nextLine(), output = "Hello!";
		boolean continueGame = true, responseExists = false;
		Converse properResponse = new Converse();
		Random ran = new Random();
		

		do {	

			
			responseExists=false;

			for( Converse arg : catalogue ) {
				if( arg.getStatement().equals(output) && arg.getResponse().equals(input) )
					arg.increaseFreq();
				else
					properResponse = new Converse(output, input, 1) ;
					responseExists = true;
			}
			if (responseExists) {
				catalogue.add( properResponse );
				responseExists=false;
			}

			for( Converse arg : catalogue ) {
				if( arg.getStatement().equals(input) ) {
					responseExists = true;
				if( arg.getFreq() > properResponse.getFreq() )
							properResponse =  arg;
				}
			}
			if (!responseExists ) {
				properResponse = catalogue.get( ran.nextInt( catalogue.size() ) );
				responseExists = false;
			}


			output = properResponse.getResponse();
			properResponse.increaseFreq();

			System.out.println(output);
			input = scan.nextLine();

			if (input.toLowerCase().equals("goodbye") )
				continueGame = false;
		} while (continueGame);
		saveFile();
	}
}